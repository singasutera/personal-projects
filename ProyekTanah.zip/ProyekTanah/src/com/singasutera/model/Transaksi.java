package com.singasutera.model;

public interface Transaksi {
	public static int harga_per_meter_persegi = 950000;
	
	public abstract int getHargaJual();
}
